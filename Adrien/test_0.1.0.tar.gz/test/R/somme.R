somme<-function(x,y){
  x+y
}
